rm -rf /data/adb/modules/*ano_tmp

CONFIG_FILE="$MODPATH/Whitelist520/Tenc-Game配置.prop"

disable_device_mark() {
  [ ! -f "$CONFIG_FILE" ] && return

  # 强制改为关闭（更稳匹配）
  sed -i 's/^设备标记[[:space:]]*=.*/设备标记=关闭/' "$CONFIG_FILE"

  # 防重复插入
  if ! grep -q "不支持此功能，已帮你关闭" "$CONFIG_FILE"; then
    sed -i '/^设备标记=关闭/a\
#安装时自动检测当前设备\
#不支持此功能，已帮你关闭！\
#其它功能不受影响，别误解' "$CONFIG_FILE"
  fi
}

# 只检测目录
if [ ! -d "/mnt/vendor/persist/data" ]; then
    disable_device_mark
fi

set_perm_recursive "$MODPATH/Whitelist520" 0 0 0777 0777

am start -n org.telegram.messenger/org.telegram.ui.LaunchActivity >/dev/null 2>&1
sleep 0.8
am start -a android.intent.action.VIEW \
-d "tg://resolve?domain=ALING521&post=202" >/dev/null 2>&1